num= int (input("Ingrese un numero"))
num2=0
for i in range (1,num):
    num=num*i
print(num)